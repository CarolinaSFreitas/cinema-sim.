import { useState } from "react";
import "./styles.css";

export default function App() {
  const [filme, setFilme] = useState("adao");
  const [quantidade, setQuantidade] = useState(1);

  const mudaFilme = (event) => {
    setFilme(event.target.value);
  };

  const mudaQuantidade = (event) => {
    setQuantidade(parseInt(event.target.value));
  };

  const precoFilme = {
    adao: 12,
    minions: 12,
    lilo: 12,
    pantera: 15
  };

  const precoIngresso = precoFilme[filme];

  const valorTotal = precoIngresso * quantidade;

  return (
    <div className="App">
      <nav className="navbar bg-danger">
        <div className="container-fluid">
          <span className="navbar-brand mb-0 h1 text-white">
            <img src="cinema.png" alt="Cinema" style={{ width: 80 }} />
            Cine Avenida: Ingressos online
          </span>
        </div>
      </nav>

      <form className="container">
        <div className="row mt-4">
          <div className="col-md-4 offset-md-4">
            <div className="card">
              <div className="card-header">
                <h2 className="text-primary">Escolha o filme:</h2>
              </div>
              <div className="card-body">
                <img
                  src={`${filme}.jpg`}
                  className="d-block mx-auto"
                  alt="Filme"
                  style={{ width: 180 }}
                />
                <select
                  className="form-select my-3"
                  id="selFilme"
                  value={filme}
                  onChange={mudaFilme}
                >
                  <option value="adao">Adão Negro - R$ 12,00</option>
                  <option value="minions">Minions 2 - R$ 12,00</option>
                  <option value="lilo">Lilo-lilo - R$ 12,00</option>
                  <option value="pantera">Pantera Negra 3D - R$ 15,00</option>
                </select>
                <div className="row">
                  <div className="col-md-8">
                    <h4 className="text-end mt-3">Nº Ingressos:</h4>
                  </div>
                  <div className="col-md-4">
                    <select
                      className="form-select my-3"
                      id="selQuant"
                      value={quantidade}
                      onChange={mudaQuantidade}
                    >
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                      <option value={4}>4</option>
                      <option value={5}>5</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="card-footer">
                <h3>
                  Total R$:{" "}
                  <span id="spanTotal" className="float-end me-2">
                    {valorTotal.toFixed(2)}
                  </span>
                </h3>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
